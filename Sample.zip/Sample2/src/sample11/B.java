package sample11;
import sample10.*;

public class B {

	public static void main(String[] args) {
		UserDefined ud=new UserDefined();
		System.out.println(ud.a);
		System.out.println(ud.b);


	}
}

