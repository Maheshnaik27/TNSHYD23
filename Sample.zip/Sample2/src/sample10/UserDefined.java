package sample10;

public class UserDefined {
	public int a=30;
public	int b=40;

}
