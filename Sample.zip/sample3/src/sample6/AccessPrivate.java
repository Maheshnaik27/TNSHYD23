package sample6;

public class AccessPrivate{
	int a=20;
	static int b=30;
	private int display() {
		return 5;
		
	}
	static void display2() {
		System.out.println("Hello this is private access");
		
	}
}
class B{
	public static void main() {
		AccessPrivate ap1=new AccessPrivate();
		System.out.println(ap1.a);
		System.out.println(ap1.display());
		System.out.println(AccessPrivate.b);
		AccessPrivate.display2();		
		
		
	}
}
