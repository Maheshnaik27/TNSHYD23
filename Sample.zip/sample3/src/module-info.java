/**
 * 
 */
/**
 * 
 */
module sample3 {
}