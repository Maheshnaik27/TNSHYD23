package sample5;
import sample4.*;


public class ReceivePublic {
	public static void main(String[] args) {
		AccessPublic ap=new AccessPublic();
		System.out.println(ap.a);
		System.out.println(AccessPublic.b);
	}

}
