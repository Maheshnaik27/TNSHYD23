package p2;

public class Approach1 {

	int a=20;
	static int b=20;
	int display() {
		return 5;
	}
 static  void  display1() {
		System.out.println("hi this is approach1");
	}
	
	public static void main(String[] args) {

		Approach1 a1=new Approach1();
		System.out.println(a1.a);
		System.out.println(a1.display());
		System.out.println(Approach1.b);
	Approach1.display1();
		
	}

}
