package sample7;

public class AccessProtected {
	int a=20;
	protected int b=30;
	

}
class B extends AccessProtected{
	public static void main(String[] args) {
		AccessProtected ap3=new AccessProtected();
		System.out.println(ap3.a);
		System.out.println(ap3.b);

	}
}
