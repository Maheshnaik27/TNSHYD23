package sample4;

public class AccessPublic {
	public int a=20; 
	public static int b=30;
	

}
