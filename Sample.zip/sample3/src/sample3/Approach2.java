package sample3;

public class Approach2 {
	int a=20;
	static int b=30;
	int display() {
		return 5;
	}
	public static void display1() {
		System.out.println("This is approach 2");	}

}
 class c{
	 public static void main(String[] args) {
		 Approach2 a2=new Approach2();
		 System.out.println(a2.a);
		 System.out.println(a2.display());
		System.out.println( Approach2.b);
		 Approach2.display1();
		 
		 
	 }
 }