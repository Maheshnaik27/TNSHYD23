package sample9;

public class AccessDefault {
	int a=30;
	static int b=30;

public static void main(String[] args) {
	AccessDefault ad=new AccessDefault();
	System.out.println(ad.a);
	System.out.println(AccessDefault.b);
	


}
}


