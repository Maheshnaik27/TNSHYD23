package m5;
import m4.*;


public class B {

	public static void main(String[] args) {
		Eductaion r=new Eductaion();
		r.setName("mahesh");
		r.setSsc("PASS");
		r.setInter("PASS");
		r.setEamcet("QUALIFIED");
		r.result("PASS", "PASS", "QUALIFIED");
		

	}

}
